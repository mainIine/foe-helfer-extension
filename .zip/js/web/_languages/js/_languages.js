﻿let Languages = {
	PossibleLanguages: {
		'cs': 'Český',
		'de': 'Deutsch',
		'dk': 'Dansk',
		'en': 'English',
		'el': 'Ελληνικά',
		'es': 'Español',
		'fr': 'Français',
		'hu': 'Magyar',
		'it': 'Italiano',
		'nl': 'Nederlands',
		'pl': 'Polski',
		'pt': 'Português',
		'pt-br': 'Português do Brasil',
		'ro': 'Română',
		'ru': 'Русский',
		'sk': 'Slovenčina',
		'sv': 'Svenska',
		'tr': 'Türkçe'
	},
};