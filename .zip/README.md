## FoE Helper
#### A small extension for the Chrome browser

You can install it from here: [Chrome Store](https://chrome.google.com/webstore/detail/foe-helper/bkagcmloachflbbkfmfiggipaelfamdf) or [Firefox Add-Ons](https://addons.mozilla.org/addon/foe-helper/)

###### FAQ

For questions and answers please use our [forum](https://forum.foe-rechner.de/).


###### Bugs & Wishes

If you find an error or have a request that is not yet available as a ticket, please use the [ticket system](https://github.com/dsiekiera/foe-helfer-extension/issues).
